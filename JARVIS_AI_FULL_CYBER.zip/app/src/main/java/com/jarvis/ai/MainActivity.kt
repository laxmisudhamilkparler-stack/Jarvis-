package com.jarvis.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JarvisApp() }
    }
}

data class ChatMessage(val text: String, val fromUser: Boolean)


class JarvisViewModel : androidx.lifecycle.ViewModel() {
    var messages by mutableStateOf(
        listOf(ChatMessage("नमस्ते! मैं JARVIS हूँ। Hindi, Hinglish या English में बात कर सकते हैं।", false))
    )
        private set

    var isThinking by mutableStateOf(false)
        private set

    fun send(text: String) {
        if (text.isBlank() || isThinking) return
        val old = messages
        messages = old + ChatMessage(text, true)
        isThinking = true
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val history = old.takeLast(20).map {
                    ChatHistoryItem(if (it.fromUser) "user" else "model", it.text)
                }
                val result = JarvisNetwork.api.chat(ChatRequest(text, history))
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    messages = messages + ChatMessage(result.reply, false)
                    isThinking = false
                }
            } catch (_: Exception) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    messages = messages + ChatMessage(
                        "Backend से connection नहीं हो पाया। Backend URL और internet check करें.",
                        false
                    )
                    isThinking = false
                }
            }
        }
    }
}

@Composable
fun JarvisApp(vm: JarvisViewModel = viewModel()) {
    val context = LocalContext.current
    var input by remember { mutableStateOf("") }
    var listening by remember { mutableStateOf(false) }
    var tts: TextToSpeech? by remember { mutableStateOf(null) }

    DisposableEffect(Unit) {
        val engine = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) engineReady = true
        }
        tts = engine
        onDispose { engine.stop(); engine.shutdown() }
    }

    val speechLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        listening = false
        val text = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!text.isNullOrBlank()) {
            input = text
            vm.send(text)
        }
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startSpeech(speechLauncher)
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF070A12),
            surface = Color(0xFF0D1220),
            primary = Color(0xFF65E8FF),
            secondary = Color(0xFF8A7CFF)
        )
    ) {
        Scaffold(
            containerColor = Color(0xFF070A12),
            topBar = {
                Row(
                    Modifier.fillMaxWidth().padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("JARVIS", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("AI ASSISTANT • ONLINE", color = Color(0xFF65E8FF), style = MaterialTheme.typography.labelSmall)
                    }
                    IconButton(onClick = {}) { Icon(Icons.Default.Settings, "Settings") }
                }
            },
            bottomBar = {
                Row(
                    Modifier.fillMaxWidth().padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = input,
                        onValueChange = { input = it },
                        modifier = Modifier.weight(1f),
                        placeholder = { Text("JARVIS को command दें...") },
                        singleLine = true
                    )
                    Spacer(Modifier.width(8.dp))
                    IconButton(
                        onClick = {
                            if (context.checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                listening = true
                                startSpeech(speechLauncher)
                            } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        },
                        modifier = Modifier.size(52.dp).background(
                            if (listening) Color(0xFF8A7CFF) else Color(0xFF123344),
                            CircleShape
                        )
                    ) { Icon(Icons.Default.Mic, "Voice") }
                    IconButton(
                        onClick = {
                            val q = input
                            input = ""
                            vm.send(q)
                        }
                    ) { Icon(Icons.Default.Send, "Send") }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding)) {
                PulsingOrb()
                LazyColumn(
                    Modifier.fillMaxSize().padding(horizontal = 12.dp),
                    reverseLayout = true
                ) {
                    items(vm.messages.reversed()) { msg ->
                        ChatBubble(msg)
                    }
                }
            }
        }
    }
}

private var engineReady = false

private fun startSpeech(
    launcher: androidx.activity.result.ActivityResultLauncher<Intent>
) {
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
        putExtra(RecognizerIntent.EXTRA_PROMPT, "JARVIS को बोलिए")
    }
    launcher.launch(intent)
}

@Composable
fun PulsingOrb() {
    val transition = rememberInfiniteTransition(label = "orb")
    val scale by transition.animateFloat(
        initialValue = 0.94f, targetValue = 1.06f,
        animationSpec = infiniteRepeatable(tween(1300), RepeatMode.Reverse),
        label = "scale"
    )
    Box(Modifier.fillMaxWidth().height(150.dp), contentAlignment = Alignment.Center) {
        Box(
            Modifier.size(110.dp).scale(scale).background(
                Brush.radialGradient(listOf(Color(0xFF65E8FF), Color(0xFF162A55), Color.Transparent)),
                CircleShape
            )
        )
        Text("J", style = MaterialTheme.typography.displayMedium, color = Color.White, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun ChatBubble(message: ChatMessage) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 5.dp),
        horizontalArrangement = if (message.fromUser) Arrangement.End else Arrangement.Start
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = if (message.fromUser) Color(0xFF153E52) else Color(0xFF101827)
        ) {
            Text(message.text, Modifier.padding(12.dp))
        }
    }
}
