
package com.jarvis.ai

import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import com.google.gson.annotations.SerializedName

data class ChatHistoryItem(
    val role: String,
    val text: String
)

data class ChatRequest(
    val message: String,
    val history: List<ChatHistoryItem> = emptyList()
)

data class ChatResponse(
    @SerializedName("reply") val reply: String
)

interface JarvisApi {
    @POST("api/chat")
    suspend fun chat(@Body request: ChatRequest): ChatResponse
}

object JarvisNetwork {
    // For production, replace this with your deployed HTTPS backend URL.
    // Example: https://your-domain.example/
    const val BASE_URL = "https://YOUR-BACKEND-DOMAIN/"

    val api: JarvisApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(JarvisApi::class.java)
    }
}
