# JARVIS AI Secure Gemini Backend

This backend keeps the Gemini API key off the Android APK.

## 1. Install
```bash
npm install
```

## 2. Configure
Copy `.env.example` to `.env` and put your Gemini API key in `GEMINI_API_KEY`.

Never commit `.env` to Git.

## 3. Run
```bash
npm run dev
```

Health check:
`GET http://localhost:8080/health`

Chat:
`POST http://localhost:8080/api/chat`

Body:
```json
{
  "message": "Namaste JARVIS",
  "history": []
}
```

## Android connection
For a phone to reach the backend, deploy this service to a reachable HTTPS server and put that base URL in the Android app. Do not use `localhost` on the phone for a remote backend.

The Gemini SDK is `@google/genai`. The server calls `models.generateContent()` with the configured model.
