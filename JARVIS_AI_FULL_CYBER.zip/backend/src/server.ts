import "dotenv/config";
import Fastify from "fastify";
import cors from "@fastify/cors";
import { GoogleGenAI } from "@google/genai";
import { z } from "zod";

const app = Fastify({ logger: true });
await app.register(cors, { origin: true });

const apiKey = process.env.GEMINI_API_KEY;
if (!apiKey) {
  app.log.warn("GEMINI_API_KEY is not configured. /api/chat will return a setup error.");
}

const ai = apiKey ? new GoogleGenAI({ apiKey }) : null;
const MODEL = process.env.GEMINI_MODEL || "gemini-3.8-flash";

const chatSchema = z.object({
  message: z.string().min(1).max(12000),
  history: z.array(z.object({
    role: z.enum(["user", "model"]),
    text: z.string().max(12000)
  })).max(50).default([])
});

app.get("/health", async () => ({
  ok: true,
  service: "jarvis-ai-backend",
  geminiConfigured: Boolean(apiKey)
}));

app.post("/api/chat", async (request, reply) => {
  const parsed = chatSchema.safeParse(request.body);
  if (!parsed.success) {
    return reply.code(400).send({ error: "Invalid request", details: parsed.error.flatten() });
  }

  if (!ai) {
    return reply.code(503).send({
      error: "Gemini is not configured",
      message: "Set GEMINI_API_KEY on the backend server."
    });
  }

  const { message, history } = parsed.data;

  try {
    const contents = [
      ...history.map(item => ({
        role: item.role,
        parts: [{ text: item.text }]
      })),
      { role: "user" as const, parts: [{ text: message }] }
    ];

    const response = await ai.models.generateContent({
      model: MODEL,
      contents,
      config: {
        systemInstruction:
          "You are JARVIS AI, a helpful personal assistant. Understand Hindi, Hinglish and English. " +
          "Be concise, practical and honest. Never claim an Android action was performed unless a real tool executed it. " +
          "Do not request or expose secrets such as API keys."
      }
    });

    return { reply: response.text ?? "I could not generate a response." };
  } catch (error) {
    request.log.error(error);
    return reply.code(502).send({
      error: "Gemini request failed",
      message: "Please try again."
    });
  }
});

app.listen({
  port: Number(process.env.PORT || 8080),
  host: process.env.HOST || "0.0.0.0"
}).catch(error => {
  app.log.error(error);
  process.exit(1);
});
