import Fastify from "fastify";
import cors from "@fastify/cors";
import dotenv from "dotenv";
import { GoogleGenAI } from "@google/genai";
import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";

dotenv.config();

const app = Fastify({ logger: true });
await app.register(cors, { origin: true });

const PORT = Number(process.env.PORT || 8080);
const MODEL = process.env.GEMINI_MODEL || "gemini-2.5-flash";
const ai = process.env.AI_API_KEY ? new GoogleGenAI({ apiKey: process.env.AI_API_KEY }) : null;

const outputDir = path.resolve(process.env.OUTPUT_DIR || "./outputs");
await fs.mkdir(outputDir, { recursive: true });

function safeName(name: string) {
  return name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 100);
}

function jsonReply(reply: any, payload: unknown) {
  return reply.type("application/json").send(payload);
}

app.get("/health", async () => ({ ok: true, service: "jarvis-backend" }));

app.post("/api/chat", async (request, reply) => {
  const body = request.body as { message?: string };
  const message = String(body?.message || "").trim();
  if (!message) return jsonReply(reply.code(400), { error: "message is required" });
  if (!ai) return jsonReply(reply.code(503), { error: "AI_API_KEY is not configured" });

  const response = await ai.models.generateContent({
    model: MODEL,
    contents: message,
  });
  return { text: response.text || "No response generated." };
});

app.post("/api/tools/execute", async (request, reply) => {
  const body = request.body as { tool?: string; args?: Record<string, unknown>; confirmed?: boolean };
  const tool = String(body?.tool || "");
  const args = body?.args || {};
  const confirmed = body?.confirmed === true;

  const sensitive = new Set(["create_reminder", "create_routine", "save_file", "create_pdf", "create_ppt"]);
  if (sensitive.has(tool) && !confirmed) {
    return jsonReply(reply.code(409), {
      confirmationRequired: true,
      message: `Please confirm ${tool} before execution.`,
    });
  }

  switch (tool) {
    case "create_code": {
      const language = String(args.language || "text");
      const prompt = String(args.prompt || "");
      if (!ai) return jsonReply(reply.code(503), { error: "AI_API_KEY is not configured" });
      const r = await ai.models.generateContent({
        model: MODEL,
        contents: `Generate production-quality ${language} code for:\n${prompt}\nReturn only useful code plus a short explanation.`,
      });
      return { tool, language, result: r.text || "" };
    }

    case "create_website": {
      const prompt = String(args.prompt || "");
      if (!ai) return jsonReply(reply.code(503), { error: "AI_API_KEY is not configured" });
      const r = await ai.models.generateContent({
        model: MODEL,
        contents: `Create a responsive single-page website for: ${prompt}. Return HTML with embedded CSS and JavaScript.`,
      });
      return { tool, result: r.text || "" };
    }

    case "create_pdf": {
      const title = safeName(String(args.title || "jarvis_document"));
      const content = String(args.content || "");
      const file = `${title}-${crypto.randomUUID()}.txt`;
      await fs.writeFile(path.join(outputDir, file), content, "utf8");
      return { tool, file, note: "Text source saved. Connect a PDF renderer in deployment for true PDF export." };
    }

    case "create_ppt": {
      const title = safeName(String(args.title || "jarvis_presentation"));
      const content = String(args.content || "");
      const file = `${title}-${crypto.randomUUID()}.txt`;
      await fs.writeFile(path.join(outputDir, file), content, "utf8");
      return { tool, file, note: "Presentation outline saved. Connect a PPTX renderer in deployment for true PPTX export." };
    }

    case "create_reminder": {
      const text = String(args.text || "");
      const when = String(args.when || "");
      const file = `reminder-${crypto.randomUUID()}.json`;
      await fs.writeFile(path.join(outputDir, file), JSON.stringify({ text, when }, null, 2));
      return { tool, saved: true, text, when, file };
    }

    case "create_routine": {
      const name = String(args.name || "Daily Routine");
      const items = Array.isArray(args.items) ? args.items : [];
      const file = `routine-${crypto.randomUUID()}.json`;
      await fs.writeFile(path.join(outputDir, file), JSON.stringify({ name, items }, null, 2));
      return { tool, saved: true, name, items, file };
    }

    case "list_files": {
      const files = await fs.readdir(outputDir);
      return { tool, files };
    }

    case "save_file": {
      const name = safeName(String(args.name || "jarvis-file.txt"));
      const content = String(args.content || "");
      await fs.writeFile(path.join(outputDir, name), content, "utf8");
      return { tool, saved: true, file: name };
    }

    default:
      return jsonReply(reply.code(400), { error: `Unknown tool: ${tool}` });
  }
});

app.listen({ port: PORT, host: "0.0.0.0" }).catch(err => {
  app.log.error(err);
  process.exit(1);
});
