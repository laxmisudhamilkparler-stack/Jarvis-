# JARVIS Advanced Tools

Implemented backend tool endpoints:
- `create_code`
- `create_website`
- `create_pdf` (saves source content; deploy with a PDF renderer for real PDF)
- `create_ppt` (saves presentation outline; deploy with a PPTX renderer for real PPTX)
- `create_reminder`
- `create_routine`
- `list_files`
- `save_file`

Sensitive tools require `confirmed: true`.

## Run
```bash
npm install
cp .env.example .env
# put your Gemini API key in .env
npm run dev
```

The Android app should call the backend over HTTPS in production. Do not put the Gemini key in the APK.

## Next Android integration
Wire the UI command router to POST `/api/tools/execute` and show the confirmation dialog whenever the server returns `confirmationRequired: true`.
