# JARVIS AI — Full Starter

This package extends the Android MVP + Gemini backend with a validated tool endpoint for:
PDF/source generation, PPT/source generation, coding, website generation, reminders, routines and files.

Some file formats require a renderer in the deployed backend; the included server intentionally avoids pretending that a `.txt` file is a real PDF/PPTX.

Do not embed the Gemini API key in the Android application.
