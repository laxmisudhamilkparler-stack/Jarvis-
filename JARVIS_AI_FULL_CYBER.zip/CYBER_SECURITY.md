# JARVIS Cyber Security Mode

JARVIS now includes a defensive/ethical-cybersecurity module.

## Included
- Security checklist
- Password-strength analysis
- Security-header analysis from supplied data
- Secure-code analysis
- Security report generation
- Cybersecurity lab learning plan

## Safety
Use security testing only on systems you own or are explicitly authorized to test.
This module intentionally does not implement credential theft, malware, persistence,
evasion, unauthorized access, or automated exploitation.

For real network testing, connect JARVIS to a controlled lab and add explicit
authorization checks before any scan is executed.
