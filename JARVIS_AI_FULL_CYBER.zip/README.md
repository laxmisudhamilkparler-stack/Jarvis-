# JARVIS AI + Gemini Backend

This ZIP now contains:
- Android Kotlin + Jetpack Compose JARVIS MVP
- Voice input
- Futuristic UI
- Chat history for the current session
- Android client that calls a secure backend
- Node.js + TypeScript + Fastify backend
- Official `@google/genai` SDK integration
- Gemini `generateContent` chat endpoint
- `.env.example` for the server-side API key

## Important
The Android app intentionally does NOT contain the Gemini API key.
Google recommends keeping API keys out of mobile/client apps and using a backend proxy. 

## Setup
1. Create a Gemini API key in Google AI Studio.
2. On the backend, copy:
   `backend/.env.example` -> `backend/.env`
3. Put the key into `GEMINI_API_KEY`.
4. Run:
   `cd backend`
   `npm install`
   `npm run dev`
5. Deploy the backend to an HTTPS host.
6. In:
   `app/src/main/java/com/jarvis/ai/JarvisNetwork.kt`
   replace `https://YOUR-BACKEND-DOMAIN/` with your deployed HTTPS URL.
7. Build the Android APK.

Do not upload `.env` or your Gemini API key to GitHub.

Advanced JARVIS tools (PDF/PPT, reminders, website/code generation, Android actions) should be added as validated backend tools and Android intents/services after this chat MVP works.
